import React from 'react';
import { NavLink } from 'react-router-dom';

const PlanetNavigation = () => {
  const planets = [
    { path: '/planets/soleil', name: 'Soleil' },
    { path: '/planets/mercure', name: 'Mercure' },
    { path: '/planets/venus', name: 'Vénus' },
    { path: '/planets/terre', name: 'Terre' },
    { path: '/planets/mars', name: 'Mars' },
    { path: '/planets/jupiter', name: 'Jupiter' },
    { path: '/planets/saturne', name: 'Saturne' },
    { path: '/planets/pluton', name: 'Pluton' }
  ];

  return (
    <nav className="mb-8 overflow-x-auto">
      <div className="flex gap-4 pb-2">
        {planets.map((planet) => (
          <NavLink
            key={planet.path}
            to={planet.path}
            className={({ isActive }) =>
              `px-4 py-2 rounded-full transition ${
                isActive
                  ? 'bg-yellow-400 text-black'
                  : 'text-gray-300 hover:text-yellow-400'
              }`
            }
          >
            {planet.name}
          </NavLink>
        ))}
      </div>
    </nav>
  );
};

export default PlanetNavigation;