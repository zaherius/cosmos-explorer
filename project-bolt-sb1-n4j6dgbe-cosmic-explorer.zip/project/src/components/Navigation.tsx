import React from 'react';
import { NavLink } from 'react-router-dom';
import { Star } from 'lucide-react';

const Navigation = () => {
  return (
    <nav className="fixed w-full bg-black/30 backdrop-blur-md z-50 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <NavLink to="/" className="flex items-center gap-2">
          <Star className="text-yellow-400" />
          <span className="text-xl font-bold">Cosmic Explorer</span>
        </NavLink>
        <div className="hidden md:flex items-center gap-8">
          <NavLink 
            to="/" 
            className={({ isActive }) => 
              `hover:text-yellow-400 transition ${isActive ? 'text-yellow-400' : ''}`
            }
          >
            Accueil
          </NavLink>
          <NavLink 
            to="/explore" 
            className={({ isActive }) => 
              `hover:text-yellow-400 transition ${isActive ? 'text-yellow-400' : ''}`
            }
          >
            Explorer
          </NavLink>
          <NavLink 
            to="/about" 
            className={({ isActive }) => 
              `hover:text-yellow-400 transition ${isActive ? 'text-yellow-400' : ''}`
            }
          >
            À Propos
          </NavLink>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;