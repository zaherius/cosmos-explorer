import React from 'react';
import { Outlet } from 'react-router-dom';
import Navigation from './Navigation';
import PlanetNavigation from './PlanetNavigation';

const PlanetLayout = () => {
  return (
    <div className="min-h-screen bg-[#121212] text-white">
      <Navigation />
      <main className="pt-24 px-6">
        <div className="max-w-4xl mx-auto">
          <PlanetNavigation />
          <Outlet />
        </div>
      </main>
      <footer className="bg-black py-12 px-6 mt-20">
        <div className="max-w-7xl mx-auto text-center text-gray-400">
          <p>&copy; 2024 Cosmic Explorer. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
};

export default PlanetLayout;