import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Star, ChevronDown, Facebook, Twitter, Instagram } from 'lucide-react';
import Navigation from './components/Navigation';
import PlanetLayout from './components/PlanetLayout';
import SoleilPage from './pages/SoleilPage';
import MercurePage from './pages/MercurePage';
import VenusPage from './pages/VenusPage';

function HomePage() {
  return (
    <div className="min-h-screen bg-[#121212] text-white">
      <Navigation />

      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center text-center px-6">
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=2048&auto=format&fit=crop)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'brightness(0.4)'
          }}
        />
        <div className="relative z-10 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            Explorez l'Univers avec Cosmic Explorer
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300 animate-fade-in-delay-1">
            Découvrez les merveilles de l'espace
          </p>
          <a 
            href="#explore"
            className="inline-flex items-center gap-2 bg-yellow-400 text-black px-8 py-3 rounded-full font-semibold hover:bg-yellow-300 transition animate-fade-in-delay-2"
          >
            Commencer l'Exploration
            <ChevronDown className="w-5 h-5" />
          </a>
        </div>
      </header>

      {/* Explore Section */}
      <section id="explore" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Explorer</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Planètes',
                image: 'https://images.unsplash.com/photo-1614732414444-096e5f1122d5?q=80&w=800&auto=format&fit=crop',
                description: 'Découvrez les secrets de notre système solaire',
                link: '/planets/soleil'
              },
              {
                title: 'Galaxies',
                image: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=800&auto=format&fit=crop',
                description: "Explorez les vastes étendues de l'univers"
              },
              {
                title: 'Trous Noirs',
                image: 'https://images.unsplash.com/photo-1465101162946-4377e57745c3?q=80&w=800&auto=format&fit=crop',
                description: 'Plongez dans les mystères des trous noirs'
              }
            ].map((category, index) => (
              <div 
                key={index}
                className="group bg-gray-900 rounded-xl overflow-hidden hover:transform hover:scale-105 transition duration-300"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={category.image} 
                    alt={category.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{category.title}</h3>
                  <p className="text-gray-400 mb-4">{category.description}</p>
                  <a 
                    href={category.link || '#'} 
                    className="text-yellow-400 hover:text-yellow-300 transition inline-flex items-center"
                  >
                    En savoir plus →
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6 bg-gray-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">À Propos</h2>
          <p className="text-gray-300 text-lg mb-8">
            Cosmic Explorer est votre guide pour explorer les mystères de l'univers. 
            Notre mission est de rendre l'astronomie accessible à tous et de partager 
            la beauté infinie de l'espace.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <Star className="text-yellow-400" />
              <span className="text-xl font-bold">Cosmic Explorer</span>
            </div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-yellow-400 transition">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="hover:text-yellow-400 transition">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="#" className="hover:text-yellow-400 transition">
                <Instagram className="w-6 h-6" />
              </a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
            <p>&copy; 2024 Cosmic Explorer. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/planets" element={<PlanetLayout />}>
        <Route path="soleil" element={<SoleilPage />} />
        <Route path="mercure" element={<MercurePage />} />
        <Route path="venus" element={<VenusPage />} />
      </Route>
    </Routes>
  );
}

export default App;