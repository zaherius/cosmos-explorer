import React from 'react';

const SoleilPage = () => {
  return (
    <article className="space-y-8">
      <header>
        <h1 className="text-4xl font-bold mb-6">Le Soleil : Au Cœur de Notre Système Solaire</h1>
      </header>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Caractéristiques Générales</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Type d'étoile :</strong> Naine jaune de type spectral G2V</li>
          <li><strong className="text-white">Âge :</strong> 4,6 milliards d'années</li>
          <li><strong className="text-white">Masse :</strong> 1,989 × 10³⁰ kg (99,85 % du Système solaire)</li>
          <li><strong className="text-white">Diamètre :</strong> 1,39 million de kilomètres</li>
          <li><strong className="text-white">Luminosité :</strong> 3,828 × 10²⁶ watts</li>
          <li><strong className="text-white">Distance moyenne de la Terre :</strong> 150 millions de kilomètres</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Composition et Structure Interne</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Composition :</strong> Principalement hydrogène (74 %) et hélium (24 %) ; 2 % de métaux</li>
          <li><strong className="text-white">Noyau :</strong> Occupe environ 25 % du rayon solaire, avec des températures d'environ 15 millions K</li>
          <li><strong className="text-white">Zone radiative :</strong> Transfert de l'énergie par rayonnement</li>
          <li><strong className="text-white">Zone convective :</strong> Transport de l'énergie par convection</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Températures et Dynamique</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Température au noyau :</strong> Environ 15 millions K</li>
          <li><strong className="text-white">Photosphère :</strong> Environ 5800 K, source de la lumière visible</li>
          <li><strong className="text-white">Couronne :</strong> Peut atteindre 1 à 3 millions K</li>
        </ul>
      </section>

      <footer className="mt-12 p-6 bg-gray-900 rounded-lg">
        <p className="text-gray-300">
          En résumé, le Soleil est une étoile complexe et dynamique dont les propriétés définissent 
          l'environnement de l'ensemble du Système solaire. Sa stabilité a permis le développement 
          de la vie sur Terre et continue d'influencer tous les corps célestes qui l'entourent.
        </p>
      </footer>
    </article>
  );
};

export default SoleilPage;