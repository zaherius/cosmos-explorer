import React from 'react';

const VenusPage = () => {
  return (
    <article className="space-y-8">
      <header>
        <h1 className="text-4xl font-bold mb-6">Vénus : La Planète Sœur à l'Atmosphère Infernale</h1>
      </header>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Caractéristiques Générales</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Distance du Soleil :</strong> Environ 108 millions de km</li>
          <li><strong className="text-white">Période orbitale :</strong> Environ 225 jours terrestres</li>
          <li><strong className="text-white">Diamètre :</strong> ~12 104 km</li>
          <li><strong className="text-white">Masse :</strong> ~4,87 × 10²⁴ kg (81,5 % de la masse terrestre)</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Composition et Structure Interne</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Structure :</strong> Similaire à la Terre (croûte, manteau, noyau)</li>
          <li><strong className="text-white">Surface :</strong> Principalement constituée de plaines volcaniques</li>
          <li><strong className="text-white">Activité :</strong> Renouvellement global par volcanisme</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Atmosphère et Températures</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Composition atmosphérique :</strong> 96 % de CO₂, nuages d'acide sulfurique</li>
          <li><strong className="text-white">Pression en surface :</strong> ~92 fois celle de la Terre</li>
          <li><strong className="text-white">Température de surface :</strong> Environ 480 °C</li>
          <li><strong className="text-white">Rotation :</strong> Lente et rétrograde (243 jours)</li>
        </ul>
      </section>

      <footer className="mt-12 p-6 bg-gray-900 rounded-lg">
        <p className="text-gray-300">
          En résumé, Vénus est une planète aux similitudes structurelles avec la Terre, 
          mais dont l'atmosphère épaisse et le fort effet de serre créent des conditions 
          inhospitalières, offrant un exemple fascinant de l'impact des environnements 
          extrêmes sur l'évolution planétaire.
        </p>
      </footer>
    </article>
  );
};

export default VenusPage;