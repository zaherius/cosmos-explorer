import React from 'react';

const MercurePage = () => {
  return (
    <article className="space-y-8">
      <header>
        <h1 className="text-4xl font-bold mb-6">Mercure : La Planète Proche du Soleil</h1>
      </header>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Caractéristiques Générales</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Distance moyenne du Soleil :</strong> ~58 millions de km</li>
          <li><strong className="text-white">Période orbitale :</strong> Environ 88 jours terrestres</li>
          <li><strong className="text-white">Diamètre :</strong> ~4 878 km</li>
          <li><strong className="text-white">Masse :</strong> ~3,30 × 10²³ kg (≈5,5 % de la masse terrestre)</li>
          <li><strong className="text-white">Gravité en surface :</strong> ~3,7 m/s²</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Composition et Structure Interne</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Surface :</strong> Rocheuse composée de basalte et de silicates</li>
          <li><strong className="text-white">Noyau :</strong> Métallique riche en fer et en nickel</li>
          <li><strong className="text-white">Champ magnétique :</strong> Faible (~1 % de celui de la Terre)</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Températures et Conditions de Surface</h2>
        <ul className="space-y-2 text-gray-300">
          <li><strong className="text-white">Température de jour :</strong> Peut atteindre ~430 °C</li>
          <li><strong className="text-white">Température de nuit :</strong> Peut descendre jusqu'à ~–180 °C</li>
          <li><strong className="text-white">Atmosphère :</strong> Quasi inexistante</li>
          <li><strong className="text-white">Surface :</strong> Criblée de cratères</li>
        </ul>
      </section>

      <footer className="mt-12 p-6 bg-gray-900 rounded-lg">
        <p className="text-gray-300">
          En résumé, Mercure est une planète aux conditions extrêmes, sans atmosphère, 
          avec un noyau très développé et des températures oscillant de 430 °C à –180 °C, 
          offrant un aperçu précieux des processus de formation planétaire près du Soleil.
        </p>
      </footer>
    </article>
  );
};

export default MercurePage;